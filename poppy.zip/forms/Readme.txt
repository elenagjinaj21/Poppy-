Fully working PHP/AJAX contact form script is available in the pro version of the template.
You can buy it from: https://bootstrapmade.com/delicious-free-restaurant-bootstrap-theme/